/****************************************************************************
  FileName     [ myString.cpp ]
  PackageName  [ util ]
  Synopsis     [ Customized string processing functions ]
  Author       [ Chung-Yang (Ric) Huang ]
  Copyright    [ Copyleft(c) 2007-present LaDs(III), GIEE, NTU, Taiwan ]
****************************************************************************/
#include <string>
#include <ctype.h>
#include <string.h>
#include <cassert>

using namespace std;

// 1. strlen(s1) must >= n
// 2. The first n characters of s2 are mandatory, they must be case-
//    insensitively compared to s1. Return less or greater than 0 if unequal.
// 3. The rest of s2 are optional. Return 0 if EOF of s2 is encountered.
//    Otherwise, perform case-insensitive comparison until non-equal result
//    presents.
//
int
myStrNCmp(const string& s1, const string& s2, unsigned n)
{
   assert(n > 0);
   if (s2.size() == 0) return -1;
   unsigned l = s1.size();
   assert(l >= n);
   for (unsigned i = 0; i < l; ++i) {
      if (!s2[i])
         return (i < n)? 1 : 0;
      char ch1 = (isupper(s1[i]))? tolower(s1[i]) : s1[i];
      char ch2 = (isupper(s2[i]))? tolower(s2[i]) : s2[i];
      if (ch1 != ch2)
         return (ch1 - ch2);
   }
   return (l - s2.size());
}


// Parse the string "str" for the token "tok", beginning at position "pos",
// with delimiter "del". The leading "del" will be skipped.
// Return "string::npos" if not found. Return the past to the end of "tok"
// (i.e. "del" or string::npos) if found.
//
size_t
myStrGetTok(const string& str, string& tok, size_t pos = 0,
            const char del = ' ')
{
   size_t begin = str.find_first_not_of(del, pos);
   if (begin == string::npos) { tok = ""; return begin; }
   size_t end = str.find_first_of(del, begin);
   tok = str.substr(begin, end - begin);
   return end;
}


// Convert string "str" to integer "num". Return false if str does not appear
// to be a number
bool
myStr2Int(const string& str, int& num)
{
   num = 0;
   size_t i = 0;
   int sign = 1;
   if (str[0] == '-') { sign = -1; i = 1; }
   bool valid = false;
   for (; i < str.size(); ++i) {
      if (isdigit(str[i])) {
         num *= 10;
         num += int(str[i] - '0');
         valid = true;
      }
      else return false;
   }
   num *= sign;
   return valid;
}

// Valid var name is ---
// 1. starts with [a-zA-Z_]
// 2. others, can only be [a-zA-Z0-9_]
// return false if not a var name
bool
isValidVarName(const string& str)
{
   size_t n = str.size();
   if (n == 0) return false;
   if (!isalpha(str[0]) && str[0] != '_')
      return false;
   for (size_t i = 1; i < n; ++i)
      if (!isalnum(str[i]) && str[i] != '_')
         return false;
   return true;
}
